import matplotlib.pyplot as plt
from keras.preprocessing.image import load_img

# Load the image
img_path = 'Insect.PNG'
img = load_img(img_path)

# Print details about the image
print(type(img))
print(img.format)
print(img.mode)
print(img.size)

# Display the image
plt.imshow(img)
plt.axis('off')
plt.show()